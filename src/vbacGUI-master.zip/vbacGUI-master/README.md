# vbacGUI

a GUI Frontend of the package including vbac &amp; pt for VBA-er

## Required Enviroment

- Windows 7, 8
- .NET Framework 4.5

# Acknowledgement
- vbac.wsf is created by @igeta
-- https://github.com/vbaidiot/Ariawase
- pt.exe is created by @monochromegane
-- https://github.com/monochromegane/the_platinum_searcher

# Code Status
- [![Build status](https://ci.appveyor.com/api/projects/status/pc20fgbvntqjq0jo)](https://ci.appveyor.com/project/dck-jp/vbacgui)
